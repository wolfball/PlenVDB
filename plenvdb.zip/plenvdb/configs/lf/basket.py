_base_ = './lf_default.py'

expname = 'dvgo_Basket_unbounded'

data = dict(
    datadir='./data/lf_data/basket',
)

