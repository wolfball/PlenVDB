_base_ = './lf_default.py'

expname = 'dvgo_Ship_unbounded'

data = dict(
    datadir='./data/lf_data/ship',
)

