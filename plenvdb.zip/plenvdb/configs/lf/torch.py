_base_ = './lf_default.py'

expname = 'dvgo_Torch_unbounded'

data = dict(
    datadir='./data/lf_data/torch',
)

