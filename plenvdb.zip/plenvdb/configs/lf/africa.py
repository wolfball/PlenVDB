_base_ = './lf_default.py'

expname = 'dvgo_Africa_unbounded'

data = dict(
    datadir='./data/lf_data/africa',
)

