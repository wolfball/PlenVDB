_base_ = './llff_default_lg.py'

expname = 'flower_lg'

data = dict(
    datadir='./data/nerf_llff_data/flower',
)

