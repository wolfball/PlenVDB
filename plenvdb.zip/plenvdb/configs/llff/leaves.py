_base_ = './llff_default.py'

expname = 'leaves'

data = dict(
    datadir='./data/nerf_llff_data/leaves',
)

