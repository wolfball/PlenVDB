_base_ = './llff_default_lg.py'

expname = 'trex_lg'

data = dict(
    datadir='./data/nerf_llff_data/trex',
)

