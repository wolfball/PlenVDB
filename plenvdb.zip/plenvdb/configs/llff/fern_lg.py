_base_ = './llff_default_lg.py'

expname = 'fern_lg'

data = dict(
    datadir='./data/nerf_llff_data/fern',
)

