_base_ = './llff_default.py'

expname = 'flower'

data = dict(
    datadir='./data/nerf_llff_data/flower',
)

