_base_ = './llff_default.py'

expname = 'trex'

data = dict(
    datadir='./data/nerf_llff_data/trex',
)

