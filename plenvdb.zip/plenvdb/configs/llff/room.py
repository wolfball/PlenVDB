_base_ = './llff_default.py'

expname = 'room'

data = dict(
    datadir='./data/nerf_llff_data/room',
)

