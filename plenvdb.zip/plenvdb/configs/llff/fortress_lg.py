_base_ = './llff_default_lg.py'

expname = 'fortress_lg'

data = dict(
    datadir='./data/nerf_llff_data/fortress',
)

