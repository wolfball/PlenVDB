_base_ = './llff_default_lg.py'

expname = 'leaves_lg'

data = dict(
    datadir='./data/nerf_llff_data/leaves',
)

