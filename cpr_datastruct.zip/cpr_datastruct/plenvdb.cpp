#include "plenvdb.h"

PYBIND11_MODULE(plenvdb, m){
    py::class_<Svox1Renderer>(m, "Svox1Renderer")
        .def(py::init<std::vector<int>, int>())
        .def("load_data", [](Svox1Renderer &p, py::buffer d, py::buffer c, int N){
            py::buffer_info infod = d.request();
            py::buffer_info infoc = c.request();
            return p.load_data(static_cast<float*>(infod.ptr), static_cast<int*>(infoc.ptr), N);
        })
        .def("ray_march", &Svox1Renderer::ray_march);

    py::class_<Svox2Renderer>(m, "Svox2Renderer")
        .def(py::init<std::vector<int>, int>())
        .def("load_data", [](Svox2Renderer &p, py::buffer ddata, py::buffer cdata, py::buffer lks, int N){
            py::buffer_info infod = ddata.request();
            py::buffer_info infoc = cdata.request();
            py::buffer_info infol = lks.request();
            return p.load_data(static_cast<float*>(infod.ptr), static_cast<float*>(infoc.ptr), static_cast<int*>(infol.ptr), N);
        })
        .def("ray_march", &Svox2Renderer::ray_march);
    
    py::class_<VDBRenderer>(m, "VDBRenderer")
        .def(py::init<std::vector<int>, int>())
        .def("load_data", [](VDBRenderer &p, py::buffer ddata, py::buffer cdata, std::string vdbdir, int N){
            py::buffer_info infod = ddata.request();
            py::buffer_info infoc = cdata.request();
            return p.load_data(static_cast<float*>(infod.ptr), static_cast<float*>(infoc.ptr), vdbdir, N);
        })
        .def("ray_march", &VDBRenderer::ray_march);
}