/*!
    \file plenvdb.h

    \version PlenVDB1.0 
    
    \brief Implements a sparse-volumn data structure based on VDB to accelerate NeRF training and rendering.

    \note There are some limitations in this version:
          (1) Only be used to train bounded scene (e.g. nerf_synthetic)
          (2) We have not updated the topology fo data during training, so in training stage the data is always dense. To make fully use
              of VDB, sparse data in training is preferred. 
          (3) In future, stream will be used in CUDA acceleration
          (4) In future, merge @MaskGrid in DVGO to plenvdb.h
          (5) @save_to function is not optimal while many leaf can be background value.
          (6) @load_from function will modify the reso (may cause bugs in special cases...)
          (7) Updated NanoVDB has Accessor with @probeLeaf which can improve @accumulate
          (8) Updated NanoVDB has IndexGrid which can replace GridType

    Overview: There are four parts implemented in this file: GridType, VDBType, OptType and Renderer.
        
        GridType -  The basic data structure of PlenVDB: @BaseGrid, and two derived data structures: @ScaleGrid and @VectorGrid.
                    ScaleGrid contains only one FloatGrid, while VectorGrid contains @nVec Vec3fGrids. This part can not be interacted 
                    with users.
        
        VDBType  -  Make GridType meaningful: @DensityVDB and @ColorVDB, both derived from @BaseVDB. Each VDB contains two Grids: one for 
                    storing data and the other for storing gradient.

        OptType  -  Adam optimizer used for training: @BaseOptimizer, @DensityOpt and @ColorOpt. Each optimizer contains an exp_avg and
                    an exp_avg_sq, both are a type of @BaseGrid.

        Renderer -  Used for fast rendering, not well implemented. 
*/


#include <cuda_runtime.h>
#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <pybind11/stl.h>
#include <vector>
#include <stdio.h>
#include <cmath>
#include <string>
#include <assert.h>
#include <ctime>

#include <openvdb/openvdb.h>
#include <openvdb/tools/Dense.h>
#include <openvdb/tools/Prune.h>
#include <nanovdb/util/OpenToNanoVDB.h> // converter from OpenVDB to NanoVDB (includes NanoVDB.h and GridManager.h)
#include <nanovdb/util/CudaDeviceBuffer.h>
#include <nanovdb/util/IO.h>
#include <nanovdb/util/NanoToOpenVDB.h>

namespace py = pybind11;
#define BufferT nanovdb::CudaDeviceBuffer
#define HandleT nanovdb::GridHandle<BufferT>
#define OpenToNanoOP nanovdb::openToNanoVDB<BufferT>
#define NanoToOpenOP nanovdb::nanoToOpenVDB<BufferT>
#define copyFromDenseOP openvdb::tools::copyFromDense
#define copyToDenseOP openvdb::tools::copyToDense
#define OpenCoordT openvdb::Coord
#define OpenBBoxT openvdb::CoordBBox

#define OpenVec3f openvdb::Vec3f
#define NanoVec3f nanovdb::Vec3f
#define OpenFloatGrid openvdb::FloatGrid
#define OpenVec3fGrid openvdb::Vec3fGrid
#define NanoFloatGrid nanovdb::NanoGrid<float>
#define NanoVec3fGrid nanovdb::NanoGrid<NanoVec3f>
#define FloatDense openvdb::tools::Dense<float>
#define Vec3fDense openvdb::tools::Dense<OpenVec3f>
#define OpenFloatTree openvdb::FloatTree
#define OpenVec3fTree openvdb::Vec3fTree

#define NanoFloatAccT nanovdb::DefaultReadAccessor<float>
#define NanoVec3fAccT nanovdb::DefaultReadAccessor<NanoVec3f>

void svox1_ray_march(float, float, float, float, float, float, float, int, int, int, int, float*, int*, int);
void svox2_ray_march(float, float, float, float, float, float, float, int, int, int, int, float*, float*, int*, int);
void vdb_ray_march(float, float, float, float, float, float, float, int, int, int, int, float*, float*, NanoFloatGrid*, int);

class Svox1Renderer{
public:
    Svox1Renderer(std::vector<int> reso, int dim){
        rx = reso[0]; ry = reso[1]; rz = reso[2];
        data_dim = dim;
    }
    ~Svox1Renderer(){
        cudaFree(data); cudaFree(child);
    }
    void load_data(float* d, int* c, int N){
        cudaMalloc(&data, N*8*data_dim*sizeof(float));
        cudaMalloc(&child, N*8*sizeof(int));
        cudaMemcpy(data, d, N*8*data_dim*sizeof(float), cudaMemcpyHostToDevice);
        cudaMemcpy(child, c, N*8*sizeof(int), cudaMemcpyHostToDevice);
    }
    void ray_march(float ox, float oy, float oz, float dx, float dy, float dz, float stepsz, int N){
        svox1_ray_march(ox, oy, oz, dx, dy, dz, stepsz, rx, ry, rz, data_dim, data, child, N);
    }
    int rx; int ry; int rz;
    int data_dim;
    float* data;
    int* child;
};

class Svox2Renderer{
public:
    Svox2Renderer(std::vector<int> reso, int dim){
        rx = reso[0]; ry = reso[1]; rz = reso[2];
        data_dim = dim;
    }
    ~Svox2Renderer(){
        cudaFree(dendata); cudaFree(coldata); cudaFree(links);
    }
    void load_data(float* ddata, float* cdata, int* lks, int N){
        cudaMalloc(&dendata, N*sizeof(float));
        cudaMalloc(&coldata, N*(data_dim-1)*sizeof(float));
        cudaMalloc(&links, rx*ry*rz*sizeof(int));
        cudaMemcpy(dendata, ddata, N*sizeof(float), cudaMemcpyHostToDevice);
        cudaMemcpy(coldata, cdata, N*(data_dim-1)*sizeof(float), cudaMemcpyHostToDevice);
        cudaMemcpy(links, lks, rx*ry*rz*sizeof(int), cudaMemcpyHostToDevice);
    }
    void ray_march(float ox, float oy, float oz, float dx, float dy, float dz, float stepsz, int N){
        svox2_ray_march(ox, oy, oz, dx, dy, dz, stepsz, rx, ry, rz, data_dim, dendata, coldata, links, N);
    }
    int rx; int ry; int rz;
    int data_dim;
    float* dendata;
    float* coldata;
    int* links;
};

class VDBRenderer{
public:
    VDBRenderer(std::vector<int> reso, int dim){
        rx = reso[0]; ry = reso[1]; rz = reso[2];
        data_dim = dim;
    }
    ~VDBRenderer(){
        cudaFree(dendata); cudaFree(coldata);
    }
    void load_data(float* ddata, float* cdata, std::string vdbdir, int N){
        cudaMalloc(&dendata, N*sizeof(float));
        cudaMalloc(&coldata, N*(data_dim-1)*sizeof(float));
        cudaMemcpy(dendata, ddata, N*sizeof(float), cudaMemcpyHostToDevice);
        cudaMemcpy(coldata, cdata, N*(data_dim-1)*sizeof(float), cudaMemcpyHostToDevice);
        openvdb::io::File file(vdbdir);
        file.open();
        OpenFloatGrid::Ptr grid;
        for (openvdb::io::File::NameIterator nameIter = file.beginName(); nameIter != file.endName(); ++nameIter)
        {
            grid = openvdb::gridPtrCast<OpenFloatGrid>(file.readGrid(nameIter.gridName()));
            grid->pruneGrid();
            handle = OpenToNanoOP(grid); 
            break; // if many grids exist, only load first gird
        } 
        file.close();
        handle.deviceUpload();
        deviceGrid = handle.deviceGrid<float>();
    }
    void ray_march(float ox, float oy, float oz, float dx, float dy, float dz, float stepsz, int N){
        vdb_ray_march(ox, oy, oz, dx, dy, dz, stepsz, rx, ry, rz, data_dim, dendata, coldata, deviceGrid, N);
    }
    int rx; int ry; int rz;
    int data_dim;
    float* dendata;
    float* coldata;
    HandleT handle;
    NanoFloatGrid* deviceGrid; // a pointer to data on the gpu
};









